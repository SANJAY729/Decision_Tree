Open DecisionTrees.ipnyb in Google Colab.
Run the blocks from top to bottom.
Generating the graph(Question 2) will take some time.